USE sth;
DELETE FROM task_3 WHERE new_column='b'; 
DELETE FROM task_3 WHERE new_column='a'; 
DELETE FROM task_3 WHERE new_column='c'; 
