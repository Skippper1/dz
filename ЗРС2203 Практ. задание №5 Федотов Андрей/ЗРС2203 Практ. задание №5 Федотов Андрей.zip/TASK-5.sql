
INSERT INTO task_3 (new_column) VALUES ('a'), ('b'), ('c'),('d'),('e'),('f'),('g'),('h'),('i'),('j'); 
SELECT * FROM task_3