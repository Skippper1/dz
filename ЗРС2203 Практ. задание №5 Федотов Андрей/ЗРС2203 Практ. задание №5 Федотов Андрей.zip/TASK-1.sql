CREATE TABLE task_1(
numbers INT, 
clock DATE,
sth BOOLEAN,
dates VARCHAR(100)
);